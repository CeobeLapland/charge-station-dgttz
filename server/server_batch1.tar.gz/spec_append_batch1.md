<!-- ↓↓↓ 粘到 docs/content/spec-协议.md 的「订单流程补充说明」小节之后，然后删掉本文件 ↓↓↓ -->

## 预约 / 智能排队（服务端已实现）

| type | 方向 | payload | 说明 |
| ---- | ---- | ---- | ---- |
| `reservation.join` | C→S | `station_id` | **不传 user_id**，身份取自连接 |
| `reservation.join_resp` | S→C | `reservation`, `matched`, `queue{queue_no, ahead_count, estimate_start_time}` | `matched=true` 表示当场分到空闲桩 |
| `reservation.cancel` | C→S | `reservation_id` | |
| `reservation.list` | C→S | — | 我的预约/排队记录（**spec 原本没有，本次新增**）|
| `push.reservation_notify` | S→用户端 | `reservation`, `charger_id`, `station_id`, `station_name`, `message` | 定向推送，只发给排到的那个人 |

**排队规则**

- 该站有空闲桩 → 直接 `matched`，把桩锁给你，`queue_no = 0`
- 没有空闲桩 → 入队，`queue_no = 当前等待人数 + 1`，预计每人 20 分钟
- **同一用户在同一站重复 join 是幂等的**：返回已有那条，不会重复排号
- 有桩空出来（订单结束 / 取消 / 预约取消）时，服务端自动把队首的人 `matched` 到那台桩上，并推送 `push.reservation_notify`
- `reservation.status`：`waiting` / `matched` / `cancelled`

## 我的车辆（服务端已实现）

| type | payload | 说明 |
| ---- | ---- | ---- |
| `vehicle.add` | `name?`, `type?`, `battery_kwh?`, `connector_type?`, `max_power_kw?` | 全部可省略，服务端给默认值（家用车 / 60kWh / dc_gb / 120kW）；**第一辆车自动设为默认车** |
| `vehicle.list` | — | `vehicles[]`，默认车排最前 |
| `vehicle.update` | `vehicle_id` + 要改的字段 | **部分更新**：没传的字段保持原值 |
| `vehicle.delete` | `vehicle_id` | **spec 原本没有，本次新增**。有进行中订单占用时返回 `2003` |

每个用户至多一辆默认车，服务端保证（设了新的默认车会自动取消旧的）。删除默认车后，剩下的第一辆自动变成默认。

## 工单 / 申诉（服务端已实现）

| type | payload | 说明 |
| ---- | ---- | ---- |
| `work_order.create` | `type?`, `station_id?`, `charger_id?`, `title?`, `description?` | `title` 和 `description` 不能都为空；`type` 不在枚举内会被纠正为 `user_complaint`；`device_fault` 自动置高优先级 |
| `work_order.list` | — | 我的工单，倒序 |

提交成功后服务端广播 `push.work_order`，管理端工单面板可据此实时刷新。

`type` 枚举：`user_complaint` / `device_fault` / `refund` / `maintenance` / `abnormal_order`

## 修改资料

| type | payload | 说明 |
| ---- | ---- | ---- |
| `user.update_profile` | `nickname?`, `avatar_path?` | 两个都不传 = 空操作；昵称超过 20 字返回 `9001` |

## 错误码补充用法

| code | 新增的使用场景 |
| ---- | ---- |
| `3002` | 对**有进行中订单**的电桩执行 `admin.charger_restart` / `admin.charger_pause` |
| `2003` | 删除**被进行中订单占用**的车辆；取消已取消的预约 |

## 给各端的两条提醒

1. **可选字段可以整个省略**。服务端对缺失的字段一律用默认值，不会报错。（此前有个 bug：缺失的 JSON key 会被当成 SQL 的 NULL 撞上 NOT NULL 约束导致"提交失败"，已修复。）
2. **所有涉及"我"的消息都不要传 `user_id`**。服务端从 WebSocket 连接上取当前登录用户，payload 里的 `user_id` 一律忽略。

<!-- ↑↑↑ 粘完删除本文件 ↑↑↑ -->
